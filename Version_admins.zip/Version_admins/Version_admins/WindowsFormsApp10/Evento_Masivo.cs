﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WindowsFormsApp10
{
    class Evento_Masivo : Evento
    {

        protected string _nombreDetalle;
        protected string _descripcion;
        protected string _descripcionAnterior;
        
        public Evento_Masivo(int id, string nombre, string pais, string fecha, string hora, string inicio, string final, string resultado, string nombreDetalle, string descripcion, string descAnt , ADODB.Connection conexion) : base(id, nombre, pais, fecha, hora, inicio, final, resultado, conexion)
        {
            _nombreDetalle = nombreDetalle;
            _descripcion = descripcion;
            _descripcionAnterior = descAnt;
        }

        public Evento_Masivo ()
        {
            _nombreDetalle = "";
            _descripcion = "";
            _descripcionAnterior = ""; 
        }

        

        public string nombreDetalle
        {
            get { return _nombreDetalle; }
            set { _nombreDetalle = value; }
        }

        public string descripcion
        {
            get { return _descripcion; }
            set { _descripcion = value; }
        }

        public string descAnt
        {
            get { return _descripcionAnterior; }
            set { _descripcionAnterior = value; }
        }

        public byte GuardarDetallesMasivo(bool alta)
        {
            byte resultado = 0;
            string sql;
            object contFilas;
            _conexion = Program.conexion;
            if (_conexion.State == 0)
            {
                resultado = 1; //conexion cerrada

            }
            else
            {

                if (alta)
                {
                    sql = "insert into masivo_detalles (id_evento,nombre_detalle,descripcion) values (" + _id + ",'" + _nombreDetalle + "','" + _descripcion + "')";


                    try
                    {
                        _conexion.Execute(sql, out contFilas);

                    }
                    catch
                    {
                        return (2);
                    }
                }
            }
            return (3);

        }

        public byte GuardarMasivo(bool alta)
        {
            byte resultado = 0;
            string sql;
            object contFilas;
            _conexion = Program.conexion;
            if (_conexion.State == 0)
            {
                resultado = 1; //conexion cerrada

            }
            else
            {

                if (alta)
                {
                    sql = "insert into masivo (descripcion) values ('" + _descripcion + "')";
                    _conexion.Execute(sql, out contFilas);


                }

                else
                {
                    //sql = "update masivo set id_evnt_mas='" + _id + "',descripcion='" + _descripcion + "' where id_evnt_mas= " + _id + "and nombre_detalle = " + _nombreDetalle + "and descripcion = " + _descripcionAnterior + ";";

                }
                try
                {

                }
                catch
                {
                    return (2);
                }
            }
            return (3);

        }



        public DataTable Listar()
        {

            object contFilas;
            string sql = "select evento.*,masivo.descripcion from evento,masivo where evento.id_evento=masivo.id_evnt_mas";
            ADODB.Recordset rs;
            _conexion = Program.conexion;
            rs = _conexion.Execute(sql, out contFilas);
            DataTable dt = new DataTable();
            OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
            adapter.Fill(dt, rs);
            return dt;

        }

        public DataTable ListarDetalles()
        {

            object contFilas;
            string sql = "select * from masivo_detalles where masivo_detalles.id_evento="+ _id + ";";
            ADODB.Recordset rs;
            _conexion = Program.conexion;
            rs = _conexion.Execute(sql, out contFilas);
            DataTable dt = new DataTable();
            OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
            adapter.Fill(dt, rs);
            return dt;

        }

    }
}
