﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
    class Equipo
    {
        protected int _id;
        protected string _equipo;
        protected string _pais;
        protected ADODB.Connection _conexion;

        public Equipo(int id, string equipo, string pais, ADODB.Connection conexion)
        {
            _id = id;
            _equipo = equipo;
            _pais = pais;
            _conexion = conexion;
        }

        public Equipo()
        {
            _id = 0;
            _equipo = "";
            _pais = "";
            _conexion = new ADODB.Connection();
        }

        public int id { 
            get 
            { 
                return _id;
            }
            set
            {
                _id = value; 
            }
        }

        public string equipo { 
            get 
            {
                return _equipo; 
            }
            set 
            { 
                _equipo = value; 
            }
        }
            
        public string pais { 
            get 
            { 
                return _pais;
            }
            set
            {
                _pais = value;
            }

        }

        public ADODB.Connection conexion {
            get 
            {
                return _conexion;
            }         
            set
            {
                _conexion = value;
            }
        }

        
    }
}
