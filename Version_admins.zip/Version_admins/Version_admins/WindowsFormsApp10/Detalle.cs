﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp10
{
     class Detalle
    {
        protected int _id;
        protected string _nombre;
        protected ADODB.Connection _conexion;


        public Detalle (int id, string nombre, ADODB.Connection conexion)
        {
            _id = id;
            _nombre = nombre;
            _conexion = conexion;
                       
        }

        public Detalle()
        {
            _id = 0;
            _nombre = "";
            _conexion = new ADODB.Connection();
        }
        public int id
            { get { return _id; } set { _id = value; } }
        public string nombre 
            { get { return _nombre; } set { _nombre = value; } }

        public ADODB.Connection conexion
            { get { return _conexion; } set { _conexion = value; } }


        public DataTable ListarComboBox()
    {

        string sql = "select * from detalles";
        object contFilas;
        ADODB.Recordset rs;
        _conexion = Program.conexion;
        rs = _conexion.Execute(sql, out contFilas);
        DataTable dt = new DataTable();
        OleDbDataAdapter adapter = new System.Data.OleDb.OleDbDataAdapter();
        adapter.Fill(dt, rs);
        return dt;


    }
    }
}
