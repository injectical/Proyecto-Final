﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class GestionDeEventosMasivos : Form
    {

        int posicion;
        public GestionDeEventosMasivos()
        {
            InitializeComponent();
        }

      


        private void nuevaLista()
        {
            Evento_Masivo lista = new Evento_Masivo();

            dgvEventos.DataSource = lista.Listar();
        }

        private void listarDeatlles()
        {
            Evento_Masivo nuevo = new Evento_Masivo();
            nuevo.id = Convert.ToInt32(txtID.Text);
            dgvDetalles.DataSource = nuevo.ListarDetalles();            
         }

        private void crearEvento(bool alta)
        //SE HACE DE ESTA FORMA PORQUE NO ES NECESARIO PASAR UN ID PARA EL ALTA
        {
            Evento nuevoEvento = new Evento();
            Evento_Masivo nuevoEventoMasivo = new Evento_Masivo();
            
            nuevoEvento.nombre = txtNombre.Text;
            nuevoEvento.pais = txtPais.Text;
            nuevoEvento.fecha = txtFecha.Text;
            nuevoEvento.hora = txtHora.Text;
            nuevoEvento.inicio = "false";
            nuevoEvento.final = "false";
            nuevoEvento.resultado = txtResultado.Text;
            nuevoEventoMasivo.nombreDetalle = cboDetalles.Text;
            nuevoEventoMasivo.descripcion = txtDescripcion.Text;


            if (!alta)
            {
               nuevoEvento.id = Convert.ToInt32(txtID.Text);
               nuevoEventoMasivo.id = Convert.ToInt32(txtIdDetalle.Text);

            }
            else
            {

            }
            nuevoEvento.Guardar(alta);
            nuevoEventoMasivo.GuardarMasivo(alta);
            limpiarTextBox();
            nuevaLista();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            crearEvento(true);
        }
        private void btnModificar_Click(object sender, EventArgs e)
        {
            crearEvento(false);
        }

        private void limpiarTextBox()
        {
            txtID.Clear();
            txtNombre.Clear();
            txtPais.Clear();
            txtFecha.Clear();
            txtHora.Clear();
            txtResultado.Clear();


        }

        private void GestionDeEventosMasivos_Load(object sender, EventArgs e)

        {
            btnVerDetalles.Visible = false;
            dgvDetalles.Visible = false;
            nuevaLista();

            Detalle listarDetalles = new Detalle();

            cboDetalles.DataSource = listarDetalles.ListarComboBox();
            cboDetalles.DisplayMember = "nombre_det";
            cboDetalles.ValueMember = "id_detalles";
            
        }

        

        private void dgvEventos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvDetalles.Visible = false;
            posicion = dgvEventos.CurrentRow.Index;

            txtID.Text = dgvEventos[0, posicion].Value.ToString();
            txtPais.Text = dgvEventos[1, posicion].Value.ToString();
            txtNombre.Text = dgvEventos[2, posicion].Value.ToString();
            txtFecha.Text = dgvEventos[3, posicion].Value.ToString();
            txtHora.Text = dgvEventos[4, posicion].Value.ToString();
            txtResultado.Text = dgvEventos[7, posicion].Value.ToString();
            txtDescripcion.Text = dgvEventos[8, posicion].Value.ToString();
            btnVerDetalles.Visible = true;
        }
        
        private void btnCargarDetalle_Click(object sender, EventArgs e)
        {
            Evento_Masivo nuevo = new Evento_Masivo();

            nuevo.id = Convert.ToInt32(txtID.Text);
            nuevo.nombreDetalle = cboDetalles.Text;
            nuevo.descripcion = txtDescripcion.Text;

            nuevo.GuardarDetallesMasivo(true);



        }
        

        private void btnVerDetalles_Click(object sender, EventArgs e)
        {
            dgvDetalles.Visible = true;
            listarDeatlles();
        }

        private void listDetalles_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
    }
 }


