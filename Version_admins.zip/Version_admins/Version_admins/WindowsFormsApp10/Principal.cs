﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
            Program.frmLogin = new Login();
            Program.frmLogin.MdiParent = this;
            Program.frmLogin.Show();
            

        }

        private void Principal_Load(object sender, EventArgs e)
        {
            menuEventos.Enabled = false;
            menuGestionUsuarios.Enabled = false;
           // Program.frmPrincipal.pcbImagen.Visible = false;





        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void menuLogin_Click(object sender, EventArgs e)
        {
            Program.conexion.Close();
            this.Close();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

      

        private void lnkEventos_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           
        }


        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void menuGestionUsuarios_Click(object sender, EventArgs e)
        {
            Program.frmgestiondeusuarios = new GestionDeUsuarios();
            Program.frmgestiondeusuarios.MdiParent = this;
            Program.frmgestiondeusuarios.Show();
        }

        private void versusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.frmgestionEventosVersus = new GestionDeEventosVersus();
            Program.frmgestionEventosVersus.MdiParent = this;
            Program.frmgestionEventosVersus.Show();
        }

        private void masivosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.frmgestionEventosMasivos = new GestionDeEventosMasivos();
            Program.frmgestionEventosMasivos.MdiParent = this;
            Program.frmgestionEventosMasivos.Show();
        }

       
    }
}
