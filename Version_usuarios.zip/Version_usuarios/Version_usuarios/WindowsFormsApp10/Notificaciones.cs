﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Notificaciones : Form
    {
        public Notificaciones()
        {
            InitializeComponent();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //ENVIARIA LA INFORMACION QUE SAQUE DEL CHECKED LISTBOX A LA TABLA DE NOTIFICACIONES DE USUARIO
            

        }

        private void clbNotificaciones_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
